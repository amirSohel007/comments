# comment widget in pure vanilla JavaScript
all the comments are getting save and delete into browser localStoge. you can also do nested comment by replying of any comment.
